#pragma once

// PUBG MOBILE (3.6.0) TELEGRAM MALIK:-@K_Y_2  
// GENERATE ON Wed Jan  8 13:08:30 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CreativeLua.CreativeBridgeLuaVM
// 0x0020 (0x01D0 - 0x01B0)
class UCreativeBridgeLuaVM : public UCreativeLuaVM
{
public:
	unsigned char                                      UnknownData00[0x4];                                       // 0x01B0(0x0004) MISSED OFFSET
	struct FString                                     RegisterUGCVMFunctionHandlerName;                         // 0x01B4(0x000C) (ZeroConstructor)
	struct FString                                     UGCVMPostInitFunctionHandlerName;                         // 0x01C0(0x000C) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x4];                                       // 0x01CC(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class CreativeLua.CreativeBridgeLuaVM");
		return pStaticClass;
	}


	void UGCLuaError(int errCode);
	void RegisterSluaCallUgcluaEventHandler();
	void PostInit();
};


}

