#pragma once

// PUBG MOBILE (3.6.0) TELEGRAM MALIK:-@K_Y_2  
// GENERATE ON Wed Jan  8 13:08:32 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum QDevKit.EQFirebaseRemoteConfigStatus
enum class EQFirebaseRemoteConfigStatus : uint8_t
{
	EQFirebaseRemoteConfigStatus__kUnfetched = 0,
	EQFirebaseRemoteConfigStatus__kFetchedSuccessfully = 1,
	EQFirebaseRemoteConfigStatus__kFetchedFailed = 2,
	EQFirebaseRemoteConfigStatus__EQFirebaseRemoteConfigStatus_MAX = 3
};



}

