#pragma once

// PUBG MOBILE (3.6.0) TELEGRAM MALIK:-@K_Y_2  
// GENERATE ON Wed Jan  8 13:08:29 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function SceneCaptureWidgetPlugin.SceneCaptureWidget.SetSceneCaptureCameraActor
struct USceneCaptureWidget_SetSceneCaptureCameraActor_Params
{
	class ASceneCaptureCameraActor*                    InSceneCaptureCameraActor;                                // (Parm, ZeroConstructor, IsPlainOldData)
};

}

